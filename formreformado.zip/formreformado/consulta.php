<?php
function insere(){
include 'conecta.php';

$stmt = $conn->query("SELECT * FROM tb_camisa");
$resultado="<table border='1'>";

while ($row = $stmt->fetchObject()) {
    $resultado .= "<tr>
    <td>$row->sg_tamanho</td>
    <td>$row->sg_cor </td>
    <td> <button class='excluir' id='$row->cd_camisa'>excluir</button></td>
    </tr>";
}
$resultado .= "</table>";
echo $resultado;
}
?>